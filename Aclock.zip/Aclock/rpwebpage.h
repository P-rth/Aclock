const char webpageprt1[] PROGMEM = R"=====(
<!DOCTYPE html>
<html lang="en" class="h-100">
<head>
    <title>AClock websettings</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
<body class="d-flex flex-column h-100">
<nav class="navbar navbar-expand-md navbar-dark bg-dark">
  <div class="container">
      <h1 class="text-white mb-0">AClock Settings</h1>
  </div>
</nav>
)=====";


const char webpageprt2[] PROGMEM = R"=====(
<main role="main">
<br> 
  <div class="container">
    <div class="form-group">
        <h2>Internet</h2>
        <div class="form-group">
            <label for="ntpserver">NTP Server:</label>
            <input type="text" class="form-control" id="ntpserver" placeholder="(Default)">
        </div>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="customDatetime">
            <label class="form-check-label" for="customDatetime">Custom Date/Time</label>
        </div>
        <div id="datetimeSettings" style="display: none;">
            <div class="form-group">
                <label for="setdate">Set Date:</label>
                <input type="date" class="form-control" id="setdate">
            </div>
            <div class="form-group">
                <label for="settime">Set Time:</label>
                <input type="time" class="form-control" id="settime">
            </div>
        </div>
        <hr>
        <h2>Weather</h2>
        <div class="form-group">
            <label for="locationCode">Location Code:</label>
            <input type="text" class="form-control" id="locationCode">
        </div>
        <div class="form-group">
            <label for="apiKey">API Key:</label>
            <input type="text" class="form-control" id="apiKey">
        </div>
        <div class="form-group">
            <label for="updateInterval">Update Interval:</label>
            <input type="number" class="form-control" id="updateInterval" placeholder="Minutes">
        </div>
        <hr>
        <h2>Sound</h2>
        <div class="form-group">
            <label for="volume">Volume:</label>
            <input type="range" class="form-control-range" id="volume" min="1" max="10" value="5">
        </div>
        <div class="form-group">
            <label for="startupSound">Startup Sound:</label>
            <input type="text" class="form-control" id="startupSound" placeholder="Enter RTTTL code">
        </div>
        <div class="form-group">
            <label for="alarmSound">Alarm Sound:</label>
            <input type="text" class="form-control" id="alarmSound" placeholder="Enter RTTTL code">
        </div>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="hourlyChime">
            <label class="form-check-label" for="hourlyChime">Hourly Chime</label>
        </div>
        <div id="hourlyChimeSettings" style="display: none;">
            <div class="form-group">
                <label for="hourlySound">Hourly Chime Sound:</label>
                <input type="text" class="form-control" id="hourlySound" placeholder="Enter RTTTL code">
            </div>
        </div>
    </div>
    <div class="form-group">
        <hr>
        <h2>Alarm</h2>
        <div class="form-check">
            <input type="checkbox" class="form-check-input" id="alarmOn">
            <label class="form-check-label" for="alarmOn">Alarm On</label>
        </div>
        <div id="alarmSettings" style="display: none;">
            <div class="form-group">
                <label for="alarmTime">Alarm Time:</label>
                <input type="time" class="form-control" id="alarmTime">
            </div>
        </div>
    </div>
    <button type="button" class="btn btn-primary" id="saveButton">Save Settings</button>
    <br>
    <br>
    <p class="h5 text-secondary" id="result">Status will be updated here</p>
  </div>
  
</main>

)=====";

const char webpageprt3[] PROGMEM = R"=====(

<script>
const res_el = document.getElementById("result");

function ajaxSuccess(data, status) {
    console.log("Received Data:", data);
    res_el.innerHTML = "Settings loaded successfully.";
    
    // Populate form fields with received settings
    $('#ntpserver').val(data.ntpserver);
    $('#customDatetime').prop('checked', data.customDatetime);
    $('#datetimeSettings').toggle(data.customDatetime);
    //$('#setdate').val(data.setdate);
    //$('#settime').val(data.settime);
    $('#locationCode').val(data.locationCode);
    $('#apiKey').val(data.apiKey);
    $('#updateInterval').val(data.updateInterval);
    $('#volume').val(data.volume);
    $('#startupSound').val(data.startupSound);
    $('#alarmSound').val(data.alarmSound);
    $('#hourlyChime').prop('checked', data.hourlyChime);
    $('#hourlyChimeSettings').toggle(data.hourlyChime);
    $('#hourlySound').val(data.hourlySound);
    $('#alarmOn').prop('checked', data.alarmOn);
    $('#alarmSettings').toggle(data.alarmOn);
    $('#alarmTime').val(data.alarmTime);
}

function ajaxError(data, status) {
    res_el.innerHTML = "Error: " + status + ": " + data;
    console.log("Status:", status);
    console.log("Error:", data);
}

// Load Settings Function
function loadSettings() {
    $.ajax({
        "url": "getsettings",
        "dataType": "json", // Expect JSON data
        "success": ajaxSuccess,
        "error": ajaxError
    });
}

// Save Settings Function
function saveSettings() {
    // Validity checks
    const locationCode = $('#locationCode').val();
    const apiKey = $('#apiKey').val();
    const updateInterval = $('#updateInterval').val();
    const alarmOn = $('#alarmOn').is(':checked');
    const alarmTime = $('#alarmTime').val();
    const customDatetime = $('#customDatetime').is(':checked');
    const setDate = $('#setdate').val();
    const setTime = $('#settime').val();

    if (!locationCode || !/^\d{7}$/.test(locationCode)) {
        alert('Location code must be a 7-digit numeric value.');
        return;
    }

    if (!apiKey) {
        alert('API key cannot be empty.');
        return;
    }

    if (updateInterval <= 0 || isNaN(updateInterval)) {
        alert('Update interval must be a positive number.');
        return;
    }

    if (alarmOn && !alarmTime) {
        alert('Alarm time cannot be blank if Alarm is turned on.');
        return;
    }

    if (customDatetime && (!setDate || !setTime)) {
        alert('Set Date and Set Time cannot be blank if Custom Date/Time is selected.');
        return;
    }

    const settings = {
        internet: {
            ntpserver: $('#ntpserver').val(),
            customDatetime: customDatetime,
            setdate: setDate,
            settime: setTime
        },
        weather: {
            locationCode: locationCode,
            apiKey: apiKey,
            updateInterval: updateInterval
        },
        sound: {
            volume: $('#volume').val(),
            startupSound: $('#startupSound').val(),
            alarmSound: $('#alarmSound').val(),
            hourlyChime: $('#hourlyChime').is(':checked'),
            hourlySound: $('#hourlySound').val()
        },
        alarm: {
            alarmOn: alarmOn,
            alarmTime: alarmTime
        }
    };

    const jsonSettings = JSON.stringify(settings); // Convert settings to JSON

    console.log("Settings:", jsonSettings);

    const params = "settings=" + encodeURIComponent(jsonSettings);;
    

    $.ajax({
        "url": "save?" + params,
        "success": ajaxSuccess,
        "error": ajaxError
    });
}

$(document).ready(function() {
    // Toggle Custom Date/Time
    $('#customDatetime').change(function() {
        $('#datetimeSettings').toggle(this.checked);
    });

    // Toggle Hourly Chime
    $('#hourlyChime').change(function() {
        $('#hourlyChimeSettings').toggle(this.checked);
    });

    // Toggle Alarm
    $('#alarmOn').change(function() {
        $('#alarmSettings').toggle(this.checked);
    });

    // Add event listener to Save Settings button
    $('#saveButton').click(saveSettings);

    // Load settings on page load
    loadSettings();
});
</script>
</body>
</html>

)=====";
